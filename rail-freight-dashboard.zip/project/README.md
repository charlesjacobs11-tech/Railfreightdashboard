# Secondary Rail Freight Market Dashboard

A self-contained web dashboard tracking secondary railcar auction market bids
(BNSF, Union Pacific, and CPKC grain shuttle / non-shuttle service) against
historical seasonal patterns, a forward-market outlook, and Pacific Northwest
bulk export volumes as a correlation factor.

No build step, no framework, no dependencies. Plain HTML/CSS/JS, hand-rolled
SVG charts, data loaded from static JSON files via `fetch()`.

## Quick start

Because the app loads its data with `fetch()`, it must be served over HTTP —
opening `index.html` directly via `file://` will fail silently (or show a
console error) due to browser CORS restrictions on local file reads.

From this folder, run any static file server, e.g.:

```bash
python3 -m http.server 8080
# then open http://localhost:8080/index.html
```

or, with Node:

```bash
npx serve .
```

## File structure

```
index.html   — markup shell: header, filter row, 6 tab buttons, 6 empty panel divs, tooltip div
styles.css   — all styling, incl. light/dark theme via CSS custom properties on :root
app.js       — all logic: data loading, chart rendering, tab rendering, filters, theme toggle
data/
  secondary_railcar_bids.json   — cleaned columnar rail-bid dataset (core dataset, all tabs)
  pnw_bulk_export_monthly.json  — monthly PNW bulk-export tonnage by port, aggregated (PNW tab)
```

### `secondary_railcar_bids.json` shape

Columnar (parallel arrays, one entry per row):

```json
{
  "companies": ["BNSF", "UP", "CPKC"],
  "types": ["Non_Shuttle", "Shuttle"],
  "date":  ["2026-07-23", ...],
  "c":     [0, 0, 1, ...],   // index into companies
  "t":     [0, 1, 0, ...],   // index into types
  "near":  [true, false, ...],  // near-month (spot) indicator
  "horizon": [0, 2, ...],       // months out this bid targets, from date
  "bid":   [193.75, -50, ...]   // $ premium (+) / discount (–) per car vs. tariff
}
```

`app.js` expands this into a `ROWS` array of row objects (`{date, t, company,
type, near, horizon, bid}`) on load, and derives `targetYearMonth(date,
horizon)` client-side to reconstruct which contract month/year each bid
applies to (this is how the forward-curve / outlook projection is built —
there's no separate "month_bid_on" field retained in the trimmed JSON).

### `pnw_bulk_export_monthly.json` shape

```json
{ "month": ["2010-01", ...], "mt": [1234567.8, ...] }
```

Monthly bulk (non-container) export tonnage summed across 8 Pacific Northwest
ports: Seattle, Tacoma, Portland OR, Vancouver WA, Longview, Kalama, Aberdeen
WA, Astoria.

## Data sources & refresh

Both datasets come from USDA AMS's AgTransport open data portal
(agtransport.usda.gov), a Socrata platform.

**Secondary railcar bids** — dataset `cvu8-kpyk`.
**PNW port exports** — dataset `v58g-swkr`.

To refresh either dataset, use the classic Socrata SODA resource endpoint —
**not** the `/api/v3/views/{id}/query.json` endpoint, which ignores
query-string parameters and always returns the entire dataset:

```
https://agtransport.usda.gov/resource/{dataset-id}.json?$limit=...&$select=...&$where=...&$order=...
```

Useful SoQL params: `$limit` / `$offset` for pagination, `$select` for column
projection or server-side aggregation (`sum(mt)`, `count(*)`), `$where` for
filtering, `$order` for sorting.

Notes learned the hard way while building v1, worth keeping in mind for any
refresh tooling:

- The `bid` field comes back as a JSON **string** (sometimes comma-formatted,
  e.g. `"1,000"`), not a number — cast/clean it on ingest.
- For the PNW dataset, filter to `conflag='Bulk'` to exclude container
  cargo (containers were explicitly excluded from this dashboard's scope).
- Prefer **OR-chained conditions** (`port='A' OR port='B' OR ...`) over SoQL
  `IN(...)` clauses when querying multiple values — `IN()` was observed to
  silently return wrong/incomplete results in this dataset via some fetch
  tooling. Keep queries simple, fetch one dimension (e.g. one port) at a
  time, and cross-validate sums (e.g. two ports' individual sums should
  exceed either alone) before trusting an aggregated result.
- Row counts as of the last refresh (2026-08-05): 16,299 rows for
  `cvu8-kpyk` (1997-05-03 through 2026-07-23), and 197 months of aggregated
  PNW bulk export data (2010-01 through 2026-05) from `v58g-swkr`.

There's no live refresh wired up — both JSON files are static snapshots. To
update them, re-query the endpoints above, re-run the same cleaning steps
(comma-strip numeric strings, cast types, recompute `horizon` as the
difference between the bid's target month/year and its report month/year),
and overwrite the files in `data/`.

## Dashboard tabs & methodology

1. **Current snapshot** — latest bid + delta vs. prior report + sparkline
   per railroad×service combination, plus the current forward curve (bid vs.
   months-out horizon).
2. **Full history** — 1997–2026 multi-line time series (near-month/spot bids
   only), with a table view toggle.
3. **Seasonal comparison** — current year plotted against all prior years by
   week-of-year, one combination at a time, with the current year's line
   extended past today using the forward-curve projection (see below).
4. **Trailing average** — weekly bid vs. a 52-week rolling average.
5. **PNW exports** — PNW bulk export volume vs. secondary rail bids, as the
   first correlation factor. Two stacked time series (not one dual-axis
   chart — tonnage and dollars aren't on a comparable scale) plus a scatter
   chart with a least-squares trend line and Pearson r. **Finding: the
   correlation is weak** (r ≈ 0.04–0.16 across all 5 combinations, monthly,
   2010–2026 overlap) — total PNW throughput alone doesn't move the
   secondary rail market much, at least not linearly at this resolution.
6. **2026 outlook** — spot (solid) vs. forward-quoted (dashed) bid by month
   for the current year, plus prior-year actuals in gray for context.

**Forward-curve / outlook methodology**: rather than a statistical
extrapolation, both the Outlook tab and the Seasonal Comparison tab's
current-year projection use the market's *own* forward bids — for each
month with no actual (near-month) bid yet, the most recently quoted forward
bid whose target contract month/year matches is used. Gaps (months the
market hasn't quoted yet — forward horizon rarely exceeds ~7 months) are
rendered as real breaks in the dashed line rather than interpolated over,
via a "run splitting" helper (`getYearProjection` / `projectedRuns` in
`app.js`) that groups projected points into contiguous month runs so a
missing month shows as a visible gap.

## Design notes

Built against a validated categorical palette (5 series colors: blue,
orange, aqua, yellow, magenta) with checked contrast/CVD-safety, light and
dark themes via CSS custom properties, crosshair+tooltip on all line charts,
legend toggle-to-isolate, and an accessible table view alongside every
chart. No external charting library — all SVG is hand-rolled in `app.js`
(`drawLineChart`, `drawSparkline`, `drawScatterChart`).

## Known limitations / open items

- No automated data refresh pipeline — see "Data sources & refresh" above.
- Only one correlation factor (PNW export volume) has been added so far;
  correlation there is weak, so likely next candidates are grain
  futures/basis, diesel fuel prices, or a lagged (rather than
  contemporaneous) version of the PNW export comparison.
- No test suite — verification so far has been manual/visual (Playwright
  screenshot checks during development).
