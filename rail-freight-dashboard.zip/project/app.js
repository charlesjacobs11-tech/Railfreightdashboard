/* ============================== DATA LOAD ============================== */
// Data files are fetched at runtime (not embedded), so this page must be served over
// HTTP — opening index.html directly via file:// will hit the browser's fetch/CORS
// restriction on local files. Any static server works, e.g.: `python3 -m http.server`
// or `npx serve`, run from the project root.
let RAW, PNW_RAW, PNW_MONTHLY, COMPANIES, TYPES, ROWS;
let COMBO_DEFS, EXISTING_COMBO_KEYS, COMBOS;
let state;

function cssVar(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

async function loadData() {
  const [rawResp, pnwResp] = await Promise.all([
    fetch('data/secondary_railcar_bids.json'),
    fetch('data/pnw_bulk_export_monthly.json'),
  ]);
  RAW = await rawResp.json();
  PNW_RAW = await pnwResp.json();
  // PNW_RAW = { month: ["2010-01",...], mt: [3199513.07,...] } — monthly BULK export tonnage,
  // summed across 8 core PNW grain terminals (Seattle, Tacoma, Portland OR, Vancouver WA,
  // Longview, Kalama, Aberdeen WA, Astoria), container cargo excluded per user request.
  PNW_MONTHLY = PNW_RAW.month.map((m, i) => ({ month: m, mt: PNW_RAW.mt[i] }));
  COMPANIES = RAW.companies;
  TYPES = RAW.types;

  ROWS = [];
  for (let i = 0; i < RAW.date.length; i++) {
    ROWS.push({
      date: RAW.date[i],
      t: Date.parse(RAW.date[i] + 'T00:00:00Z'),
      company: COMPANIES[RAW.c[i]],
      type: TYPES[RAW.t[i]],
      near: RAW.near[i],
      horizon: RAW.horizon[i],
      bid: RAW.bid[i],
    });
  }

  COMBO_DEFS = [
    { company: 'BNSF', type: 'Non_Shuttle', label: 'BNSF · Non-Shuttle', color: '--series-1' },
    { company: 'BNSF', type: 'Shuttle',     label: 'BNSF · Shuttle',     color: '--series-2' },
    { company: 'UP',   type: 'Non_Shuttle', label: 'UP · Non-Shuttle',   color: '--series-3' },
    { company: 'UP',   type: 'Shuttle',     label: 'UP · Shuttle',       color: '--series-4' },
    { company: 'CPKC', type: 'Shuttle',     label: 'CPKC · Shuttle',     color: '--series-5' },
  ].map(c => ({ ...c, key: c.company + '|' + c.type }));

  // only keep combos that actually exist in data
  EXISTING_COMBO_KEYS = new Set(ROWS.map(r => r.company + '|' + r.type));
  COMBOS = COMBO_DEFS.filter(c => EXISTING_COMBO_KEYS.has(c.key));

  const maxDate = ROWS.reduce((a, r) => Math.max(a, r.t), -Infinity);
  document.getElementById('meta-line').textContent =
    'Latest report: ' + new Date(maxDate).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }) +
    '  ·  ' + ROWS.length.toLocaleString('en-US') + ' records loaded  ·  updated ' + new Date().toISOString().slice(0,10);

  /* ============================== STATE ============================== */
  state = {
    companies: new Set(COMBOS.map(c => c.company)),
    types: new Set(COMBOS.map(c => c.type)),
    activeTab: 'snapshot',
    isolated: new Set(), // legend isolate per-tab handled locally
  };
}

/* ============================== HELPERS ============================== */
function fmtMoney(v) {
  const sign = v < 0 ? '-' : '';
  const av = Math.abs(v);
  const s = av >= 1000 ? av.toLocaleString('en-US', {maximumFractionDigits: 0}) : av.toLocaleString('en-US', {maximumFractionDigits: 2, minimumFractionDigits: 0});
  return sign + '$' + s;
}
function fmtDelta(v) {
  const sign = v > 0 ? '+' : (v < 0 ? '-' : '');
  return sign + '$' + Math.abs(Math.round(v));
}
function niceNum(range, round) {
  const exponent = Math.floor(Math.log10(range));
  const fraction = range / Math.pow(10, exponent);
  let niceFraction;
  if (round) {
    if (fraction < 1.5) niceFraction = 1;
    else if (fraction < 3) niceFraction = 2;
    else if (fraction < 7) niceFraction = 5;
    else niceFraction = 10;
  } else {
    if (fraction <= 1) niceFraction = 1;
    else if (fraction <= 2) niceFraction = 2;
    else if (fraction <= 5) niceFraction = 5;
    else niceFraction = 10;
  }
  return niceFraction * Math.pow(10, exponent);
}
function niceTicks(min, max, count) {
  if (min === max) { min -= 1; max += 1; }
  const range = niceNum(max - min, false);
  const step = niceNum(range / (count - 1), true);
  const niceMin = Math.floor(min / step) * step;
  const niceMax = Math.ceil(max / step) * step;
  const ticks = [];
  for (let v = niceMin; v <= niceMax + step * 0.5; v += step) ticks.push(Math.round(v * 1000) / 1000);
  return { ticks, min: niceMin, max: niceMax };
}
function svgEl(tag, attrs) {
  const el = document.createElementNS('http://www.w3.org/2000/svg', tag);
  for (const k in attrs) el.setAttribute(k, attrs[k]);
  return el;
}
function dayOfYearWeek(dateStr) {
  const d = new Date(dateStr + 'T00:00:00Z');
  const jan1 = Date.UTC(d.getUTCFullYear(), 0, 1);
  const doy = Math.floor((d.getTime() - jan1) / 86400000) + 1;
  return Math.ceil(doy / 7);
}

function visibleCombos() {
  return COMBOS.filter(c => state.companies.has(c.company) && state.types.has(c.type));
}

function comboRows(combo, nearOnly) {
  return ROWS.filter(r => r.company === combo.company && r.type === combo.type && (!nearOnly || r.near))
             .sort((a, b) => a.t - b.t);
}

/* ============================== GENERIC LINE CHART ============================== */
// series: [{key,label,color,points:[{x,y,raw}], muted, width, dashed}]
// opts: {xType:'time'|'week', xTicks?, yFormat, tooltipRows(xVal) -> [{label,color,value}], tooltipTitle(xVal)}
function drawLineChart(container, series, opts) {
  container.innerHTML = '';
  const W = 900, H = opts.height || 300;
  const margin = { top: 14, right: 18, bottom: 26, left: 54 };
  const innerW = W - margin.left - margin.right;
  const innerH = H - margin.top - margin.bottom;

  const allPoints = series.flatMap(s => s.points);
  if (allPoints.length === 0) {
    container.innerHTML = '<div class="empty-state">No data for the current filter selection.</div>';
    return;
  }
  const xMin = opts.xMin !== undefined ? opts.xMin : Math.min(...allPoints.map(p => p.x));
  const xMax = opts.xMax !== undefined ? opts.xMax : Math.max(...allPoints.map(p => p.x));
  let yMin = Math.min(...allPoints.map(p => p.y), 0);
  let yMax = Math.max(...allPoints.map(p => p.y), 0);
  const yPad = (yMax - yMin) * 0.08 || 1;
  const yt = niceTicks(yMin - yPad, yMax + yPad, 5);

  const xScale = x => margin.left + (xMax === xMin ? innerW / 2 : (x - xMin) / (xMax - xMin) * innerW);
  const yScale = y => margin.top + (1 - (y - yt.min) / (yt.max - yt.min)) * innerH;

  const svg = svgEl('svg', { class: 'chart-svg', viewBox: '0 0 ' + W + ' ' + H, preserveAspectRatio: 'none' });

  // gridlines
  yt.ticks.forEach(tv => {
    const y = yScale(tv);
    svg.appendChild(svgEl('line', { class: tv === 0 ? 'baseline' : 'gridline', x1: margin.left, x2: W - margin.right, y1: y, y2: y }));
    const lbl = svgEl('text', { class: 'axis-label', x: margin.left - 8, y: y + 3, 'text-anchor': 'end' });
    lbl.textContent = (opts.yFormat ? opts.yFormat(tv) : tv);
    svg.appendChild(lbl);
  });

  // x ticks
  const xTicks = opts.xTicks ? opts.xTicks(xMin, xMax) : [];
  xTicks.forEach(t => {
    const x = xScale(t.x);
    const lbl = svgEl('text', { class: 'axis-label', x: x, y: H - 6, 'text-anchor': 'middle' });
    lbl.textContent = t.label;
    svg.appendChild(lbl);
  });

  // series paths
  series.forEach(s => {
    if (s.points.length === 0) return;
    const d = s.points.map((p, i) => (i === 0 ? 'M' : 'L') + xScale(p.x).toFixed(2) + ',' + yScale(p.y).toFixed(2)).join(' ');
    const path = svgEl('path', {
      class: 'series-path' + (s.muted ? ' muted' : ''),
      d: d,
      stroke: s.muted ? '' : s.color,
    });
    if (s.width) path.setAttribute('stroke-width', s.width);
    if (s.dashed) path.setAttribute('stroke-dasharray', '5,4');
    svg.appendChild(path);

    if (!s.muted && s.points.length) {
      const last = s.points[s.points.length - 1];
      svg.appendChild(svgEl('circle', { class: 'end-dot', cx: xScale(last.x), cy: yScale(last.y), r: 4, fill: s.color }));
      if (s.directLabel !== false) {
        const lbl = svgEl('text', { class: 'direct-label', x: xScale(last.x) + 8, y: yScale(last.y) + 4, fill: s.color });
        lbl.textContent = s.label;
        svg.appendChild(lbl);
      }
    }
  });

  // interaction overlay
  const overlay = svgEl('rect', { x: margin.left, y: margin.top, width: innerW, height: innerH, fill: 'transparent' });
  const crosshair = svgEl('line', { class: 'crosshair-line', x1: 0, x2: 0, y1: margin.top, y2: margin.top + innerH, style: 'display:none' });
  svg.appendChild(crosshair);
  const dotsLayer = svgEl('g');
  svg.appendChild(dotsLayer);
  svg.appendChild(overlay);

  const tooltip = document.getElementById('tooltip');
  function findNearestX(mx) {
    // map back to data x
    const fx = xMin + (mx - margin.left) / innerW * (xMax - xMin);
    let best = null, bestD = Infinity;
    allPoints.forEach(p => { const d = Math.abs(p.x - fx); if (d < bestD) { bestD = d; best = p.x; } });
    return best;
  }
  function onMove(evt) {
    const rect = svg.getBoundingClientRect();
    const mx = (evt.clientX - rect.left) / rect.width * W;
    const nearestX = findNearestX(mx);
    if (nearestX === null) return;
    crosshair.style.display = '';
    crosshair.setAttribute('x1', xScale(nearestX));
    crosshair.setAttribute('x2', xScale(nearestX));
    dotsLayer.innerHTML = '';
    const rowsHtml = [];
    series.forEach(s => {
      const pt = s.points.find(p => p.x === nearestX) || s.points.reduce((a, p) => Math.abs(p.x - nearestX) < Math.abs((a || {x:Infinity}).x - nearestX) ? p : a, null);
      if (!pt) return;
      const col = s.muted ? cssVar('--text-muted') : s.color;
      dotsLayer.appendChild(svgEl('circle', { class: 'end-dot', cx: xScale(pt.x), cy: yScale(pt.y), r: 3.5, fill: col }));
      rowsHtml.push({ label: s.label, color: col, value: pt.raw !== undefined ? pt.raw : pt.y });
    });
    const title = opts.tooltipTitle ? opts.tooltipTitle(nearestX) : String(nearestX);
    tooltip.innerHTML = '';
    const t = document.createElement('div'); t.className = 'tt-date'; t.textContent = title; tooltip.appendChild(t);
    rowsHtml.forEach(r => {
      const row = document.createElement('div'); row.className = 'tt-row';
      const key = document.createElement('div'); key.className = 'tt-key'; key.style.background = r.color;
      const name = document.createElement('div'); name.className = 'tt-name'; name.textContent = r.label;
      const val = document.createElement('div'); val.className = 'tt-val'; val.textContent = (opts.yFormat ? opts.yFormat(r.value) : r.value);
      row.appendChild(key); row.appendChild(name); row.appendChild(val);
      tooltip.appendChild(row);
    });
    tooltip.style.opacity = '1';
    const contRect = container.getBoundingClientRect();
    let left = evt.clientX - contRect.left + 14;
    let top = evt.clientY - contRect.top - 10;
    tooltip.style.left = left + 'px';
    tooltip.style.top = top + 'px';
  }
  overlay.addEventListener('pointermove', onMove);
  overlay.addEventListener('pointerleave', () => { tooltip.style.opacity = '0'; crosshair.style.display = 'none'; dotsLayer.innerHTML = ''; });

  container.appendChild(svg);
}

function drawSparkline(container, points, color) {
  container.innerHTML = '';
  if (points.length < 2) return;
  const W = 140, H = 30;
  const xs = points.map((p, i) => i);
  const ys = points.map(p => p.y);
  const yMin = Math.min(...ys), yMax = Math.max(...ys);
  const pad = (yMax - yMin) * 0.15 || 1;
  const xScale = i => i / (points.length - 1) * (W - 4) + 2;
  const yScale = y => H - 3 - (y - (yMin - pad)) / ((yMax + pad) - (yMin - pad)) * (H - 6);
  const svg = svgEl('svg', { width: W, height: H, viewBox: '0 0 ' + W + ' ' + H });
  const d = points.map((p, i) => (i === 0 ? 'M' : 'L') + xScale(i).toFixed(1) + ',' + yScale(p.y).toFixed(1)).join(' ');
  svg.appendChild(svgEl('path', { d, fill: 'none', stroke: cssVar('--text-muted'), 'stroke-width': 1.5 }));
  const last = points[points.length - 1];
  svg.appendChild(svgEl('circle', { cx: xScale(points.length - 1), cy: yScale(last.y), r: 2.5, fill: color }));
  container.appendChild(svg);
}

/* ============================== FILTER UI ============================== */
function renderFilterUI() {
  const companyGroup = document.getElementById('company-filters');
  const typeGroup = document.getElementById('type-filters');
  companyGroup.querySelectorAll('.chip').forEach(e => e.remove());
  typeGroup.querySelectorAll('.chip').forEach(e => e.remove());

  const allCompanies = [...new Set(COMBOS.map(c => c.company))];
  allCompanies.forEach(company => {
    const chip = document.createElement('label');
    chip.className = 'chip' + (state.companies.has(company) ? ' active' : '');
    const comboForColor = COMBOS.find(c => c.company === company);
    chip.innerHTML = '<span class="dot" style="background:var(' + comboForColor.color + ')"></span>' + company;
    chip.addEventListener('click', (e) => {
      e.preventDefault();
      if (state.companies.has(company)) { if (state.companies.size > 1) state.companies.delete(company); }
      else state.companies.add(company);
      renderFilterUI();
      renderActiveTab();
    });
    companyGroup.appendChild(chip);
  });

  const allTypes = [...new Set(COMBOS.map(c => c.type))];
  const typeLabels = { Non_Shuttle: 'Non-Shuttle', Shuttle: 'Shuttle' };
  allTypes.forEach(type => {
    const chip = document.createElement('label');
    chip.className = 'chip' + (state.types.has(type) ? ' active' : '');
    chip.innerHTML = typeLabels[type] || type;
    chip.addEventListener('click', (e) => {
      e.preventDefault();
      if (state.types.has(type)) { if (state.types.size > 1) state.types.delete(type); }
      else state.types.add(type);
      renderFilterUI();
      renderActiveTab();
    });
    typeGroup.appendChild(chip);
  });
}

/* ============================== TABS ============================== */
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    state.activeTab = btn.dataset.tab;
    document.getElementById('panel-' + state.activeTab).classList.add('active');
    renderActiveTab();
  });
});

function renderActiveTab() {
  if (state.activeTab === 'snapshot') renderSnapshot();
  else if (state.activeTab === 'history') renderHistory();
  else if (state.activeTab === 'seasonal') renderSeasonal();
  else if (state.activeTab === 'trailing') renderTrailing();
  else if (state.activeTab === 'pnw') renderPnw();
  else if (state.activeTab === 'outlook') renderOutlook();
}

/* ---------- 2026 outlook tab ---------- */
function targetYearMonth(dateStr, horizon) {
  const y = Number(dateStr.slice(0,4)), m = Number(dateStr.slice(5,7));
  const total = (y*12 + (m-1)) + horizon;
  return { y: Math.floor(total/12), m: (total % 12) + 1 };
}
const MONTH_NAMES = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

// Shared by the 2026 Outlook tab and the Seasonal Comparison tab's forward-curve extension.
// Returns { actual: [{m,bid}], projected: [{m,bid,asOf}], lastActualMonth } for one combo/year.
// "projected" months are those with no near-month (spot) data yet, filled from the most
// recently quoted forward bid that targets that specific contract month.
function getYearProjection(combo, year) {
  const allRows = ROWS.filter(r => r.company === combo.company && r.type === combo.type);
  const actualByMonth = new Map();
  allRows.forEach(r => {
    if (r.near && Number(r.date.slice(0,4)) === year) {
      const m = Number(r.date.slice(5,7));
      if (!actualByMonth.has(m)) actualByMonth.set(m, []);
      actualByMonth.get(m).push(r.bid);
    }
  });
  const actual = [...actualByMonth.entries()].map(([m, vals]) => ({ m, bid: vals.reduce((a,b)=>a+b,0)/vals.length })).sort((a,b)=>a.m-b.m);
  const lastActualMonth = actual.length ? Math.max(...actual.map(a=>a.m)) : 0;

  const projected = [];
  for (let m = 1; m <= 12; m++) {
    if (actualByMonth.has(m)) continue;
    let best = null;
    allRows.forEach(r => {
      const t = targetYearMonth(r.date, r.horizon);
      if (t.y === year && t.m === m) { if (!best || r.date > best.date) best = r; }
    });
    if (best) projected.push({ m, bid: best.bid, asOf: best.date });
  }
  return { actual, projected, lastActualMonth };
}

// Splits a sorted-by-month projected array into contiguous runs (gap = no forward quote yet),
// optionally prepending a bridge point so the first run visually continues from `bridgePoint`.
// xOfMonth(m) converts a calendar month number to whatever x-coordinate the caller's chart uses
// (month number itself for Outlook, week-of-year for Seasonal).
function projectedRuns(projected, lastActualMonth, bridgePoint, xOfMonth) {
  const sorted = [...projected].sort((a,b) => a.m - b.m);
  const runs = []; let current = [];
  sorted.forEach(p => {
    if (current.length && p.m !== current[current.length-1].m + 1) { runs.push(current); current = []; }
    current.push(p);
  });
  if (current.length) runs.push(current);
  return runs.map((run, i) => {
    let pts = run.map(p => ({ x: xOfMonth(p.m), y: p.bid, raw: p.bid, m: p.m }));
    if (i === 0 && bridgePoint && run[0].m === lastActualMonth + 1) pts = [bridgePoint].concat(pts);
    return pts;
  });
}

function renderOutlook() {
  const panel = document.getElementById('panel-outlook');
  panel.innerHTML = '';
  const combos = visibleCombos();
  if (combos.length === 0) { panel.innerHTML = '<div class="empty-state">Select at least one railroad and service type above.</div>'; return; }
  if (!state.outlookFocus || !combos.find(c => c.key === state.outlookFocus)) state.outlookFocus = combos[0].key;
  const combo = combos.find(c => c.key === state.outlookFocus);
  const accent = cssVar(combo.color);
  const THIS_YEAR = 2026; // most recent year with data in this dataset

  const allRows = ROWS.filter(r => r.company === combo.company && r.type === combo.type);
  const { actual, projected, lastActualMonth } = getYearProjection(combo, THIS_YEAR);
  const asOfDates = new Set(projected.map(p => p.asOf));
  const priorYearData = getYearProjection(combo, THIS_YEAR - 1);
  const prior = priorYearData.actual;

  const head = document.createElement('div'); head.className = 'card';
  const h = document.createElement('div'); h.className = 'card-head';
  h.innerHTML = '<div><p class="card-title">' + THIS_YEAR + ' spot bid vs. forward-market projection</p>' +
    '<p class="card-caption">Solid line: actual monthly-average near-month (spot) bid. Dashed line: the most recently quoted forward bid for that specific contract month — real market pricing already in the data, not a statistical forecast. Gray: ' + (THIS_YEAR-1) + ' actual, for seasonal context.</p></div>';
  const selRow = document.createElement('div'); selRow.className = 'select-row';
  selRow.innerHTML = 'Series <select id="outlook-select"></select>';
  h.appendChild(selRow);
  head.appendChild(h);
  panel.appendChild(head);

  const sel = selRow.querySelector('#outlook-select');
  combos.forEach(c => {
    const opt = document.createElement('option'); opt.value = c.key; opt.textContent = c.label;
    if (c.key === state.outlookFocus) opt.selected = true;
    sel.appendChild(opt);
  });
  sel.addEventListener('change', () => { state.outlookFocus = sel.value; renderOutlook(); });

  // stat tiles
  const latestSpot = allRows.filter(r=>r.near).sort((a,b)=>a.t-b.t).slice(-1)[0];
  const ytdAvg = actual.length ? actual.reduce((a,r)=>a+r.bid,0)/actual.length : null;
  const projAvg = projected.length ? projected.reduce((a,r)=>a+r.bid,0)/projected.length : null;
  const delta = (projAvg !== null && ytdAvg !== null) ? projAvg - ytdAvg : null;
  const deltaClass = delta === null ? 'flat' : (delta > 0 ? 'up' : (delta < 0 ? 'down' : 'flat'));

  const kpiCard = document.createElement('div'); kpiCard.className = 'card';
  const kpiRow = document.createElement('div'); kpiRow.className = 'kpi-row';
  kpiRow.innerHTML =
    '<div class="stat-tile"><div class="st-label">Latest spot bid</div><div class="st-value">' + (latestSpot ? fmtMoney(latestSpot.bid) : 'n/a') + '</div><div class="st-date">as of ' + (latestSpot ? latestSpot.date : '—') + '</div></div>' +
    '<div class="stat-tile"><div class="st-label">' + THIS_YEAR + ' YTD average (actual)</div><div class="st-value">' + (ytdAvg !== null ? fmtMoney(ytdAvg) : 'n/a') + '</div><div class="st-date">' + (actual.length ? MONTH_NAMES[actual[0].m-1] + '–' + MONTH_NAMES[lastActualMonth-1] : '') + '</div></div>' +
    '<div class="stat-tile"><div class="st-label">Projected remaining-' + THIS_YEAR + ' average</div><div class="st-value">' + (projAvg !== null ? fmtMoney(projAvg) : 'no forward quotes yet') + '</div>' + (delta !== null ? ('<div class="st-delta ' + deltaClass + '">' + fmtDelta(delta) + ' vs YTD actual</div>') : '') + '</div>';
  kpiCard.appendChild(kpiRow);
  panel.appendChild(kpiCard);

  // chart: x = month 1-12, series: prior year (muted), actual (solid accent), projected (dashed accent)
  const chartCard = document.createElement('div'); chartCard.className = 'card';
  chartCard.innerHTML = '<div class="card-head"><div><p class="card-title">Month-by-month, ' + THIS_YEAR + '</p></div></div>';
  const chartDiv = document.createElement('div'); chartDiv.className = 'chart-wrap';
  chartCard.appendChild(chartDiv);
  const legendDiv = document.createElement('div'); legendDiv.className = 'legend';
  chartCard.appendChild(legendDiv);
  panel.appendChild(chartCard);

  const series = [];
  if (prior.length) series.push({ key:'prior', label: String(THIS_YEAR-1), muted:true, points: prior.map(p=>({x:p.m,y:p.bid,raw:p.bid})), directLabel:false });
  if (actual.length) series.push({ key:'actual', label: THIS_YEAR + ' actual (spot)', color: accent, points: actual.map(p=>({x:p.m,y:p.bid,raw:p.bid})), directLabel:false, width:2.5 });
  if (projected.length) {
    // Break into contiguous month runs so a missing month (no forward quote yet) shows as a
    // real gap rather than a straight line silently bridging over it. Only the first run —
    // if it starts right after the last actual month — gets the actual line's endpoint
    // prepended, so the dashed segment visually continues from the solid line.
    const bridge = actual.length ? { x: lastActualMonth, y: actual.find(a=>a.m===lastActualMonth).bid, raw: actual.find(a=>a.m===lastActualMonth).bid } : null;
    const runs = projectedRuns(projected, lastActualMonth, bridge, m => m);
    runs.forEach((pts, i) => {
      series.push({ key: 'projected-' + i, label: THIS_YEAR + ' forward-quoted', color: accent, points: pts, directLabel: false, width: 2.5, dashed: true });
    });
  }

  drawLineChart(chartDiv, series, {
    height: 300, yFormat: fmtMoney,
    xMin: 1, xMax: 12,
    xTicks: () => MONTH_NAMES.map((name,i) => ({ x: i+1, label: name })),
    tooltipTitle: (x) => MONTH_NAMES[Math.round(x)-1] + ' ' + THIS_YEAR,
  });

  legendDiv.innerHTML = '';
  if (prior.length) legendDiv.innerHTML += '<div class="legend-item"><span class="key" style="background:' + cssVar('--text-muted') + '"></span>' + (THIS_YEAR-1) + ' actual</div>';
  if (actual.length) legendDiv.innerHTML += '<div class="legend-item"><span class="key" style="background:' + accent + '"></span>' + THIS_YEAR + ' actual (spot)</div>';
  if (projected.length) legendDiv.innerHTML += '<div class="legend-item"><span class="key" style="background:' + accent + ';background-image:linear-gradient(90deg,' + accent + ' 60%,transparent 0);background-size:8px 2px;"></span>' + THIS_YEAR + ' forward-quoted (dashed)</div>';

  if (projected.length) {
    const note = document.createElement('p'); note.className = 'card-caption'; note.style.marginTop = '10px';
    const latestAsOf = [...asOfDates].sort().slice(-1)[0];
    note.textContent = 'Forward quotes as of report dates through ' + latestAsOf + '. Months with no forward quote yet (bids beyond the market\'s current quoting horizon) are left blank rather than estimated.';
    chartCard.appendChild(note);
  }

  // table view
  const tableToggle = document.createElement('button'); tableToggle.className = 'table-toggle-btn'; tableToggle.textContent = 'Table view'; tableToggle.style.marginTop = '10px';
  chartCard.appendChild(tableToggle);
  const tableDiv = document.createElement('div'); tableDiv.style.display = 'none'; tableDiv.style.marginTop = '10px';
  chartCard.appendChild(tableDiv);
  let shown = false;
  tableToggle.addEventListener('click', () => {
    shown = !shown; tableToggle.classList.toggle('active', shown); tableDiv.style.display = shown ? '' : 'none';
    if (shown && tableDiv.innerHTML === '') {
      let html = '<div class="table-scroll"><table class="data-table"><thead><tr><th>Month</th><th>' + (THIS_YEAR-1) + ' actual</th><th>' + THIS_YEAR + ' actual</th><th>' + THIS_YEAR + ' forward-quoted</th></tr></thead><tbody>';
      for (let m = 1; m <= 12; m++) {
        const pv = prior.find(p=>p.m===m), av = actual.find(p=>p.m===m), pj = projected.find(p=>p.m===m);
        html += '<tr><td>' + MONTH_NAMES[m-1] + '</td><td>' + (pv?fmtMoney(pv.bid):'—') + '</td><td>' + (av?fmtMoney(av.bid):'—') + '</td><td>' + (pj?fmtMoney(pj.bid):'—') + '</td></tr>';
      }
      html += '</tbody></table></div>';
      tableDiv.innerHTML = html;
    }
  });
}

/* ============================== Correlation helpers ============================== */
function pearsonR(xs, ys) {
  const n = xs.length;
  if (n < 3) return null;
  const mx = xs.reduce((a,b)=>a+b,0) / n, my = ys.reduce((a,b)=>a+b,0) / n;
  let num = 0, dx2 = 0, dy2 = 0;
  for (let i = 0; i < n; i++) {
    const dx = xs[i]-mx, dy = ys[i]-my;
    num += dx*dy; dx2 += dx*dx; dy2 += dy*dy;
  }
  const denom = Math.sqrt(dx2*dy2);
  return denom === 0 ? null : num/denom;
}
function linRegress(xs, ys) {
  const n = xs.length;
  const mx = xs.reduce((a,b)=>a+b,0) / n, my = ys.reduce((a,b)=>a+b,0) / n;
  let num = 0, den = 0;
  for (let i = 0; i < n; i++) { num += (xs[i]-mx)*(ys[i]-my); den += (xs[i]-mx)*(xs[i]-mx); }
  const slope = den === 0 ? 0 : num/den;
  const intercept = my - slope*mx;
  return { slope, intercept };
}
function corrStrengthLabel(r) {
  const a = Math.abs(r);
  const dir = r >= 0 ? 'positive' : 'negative';
  let strength;
  if (a < 0.2) strength = 'very weak';
  else if (a < 0.4) strength = 'weak';
  else if (a < 0.6) strength = 'moderate';
  else if (a < 0.8) strength = 'strong';
  else strength = 'very strong';
  return strength + ' ' + dir;
}
function fmtMt(v) {
  return (v/1e6).toLocaleString('en-US', {maximumFractionDigits: 2}) + 'M MT';
}

/* ---------- PNW exports tab ---------- */
function renderPnw() {
  const panel = document.getElementById('panel-pnw');
  panel.innerHTML = '';
  const combos = visibleCombos();
  if (combos.length === 0) { panel.innerHTML = '<div class="empty-state">Select at least one railroad and service type above.</div>'; return; }
  if (!state.pnwFocus || !combos.find(c => c.key === state.pnwFocus)) state.pnwFocus = combos[0].key;
  const combo = combos.find(c => c.key === state.pnwFocus);
  const accent = cssVar(combo.color);
  const pnwHue = cssVar('--series-1');

  // monthly avg near-month bid for this combo
  const rows = comboRows(combo, true);
  const byMonth = new Map();
  rows.forEach(r => {
    const m = r.date.slice(0,7);
    if (!byMonth.has(m)) byMonth.set(m, []);
    byMonth.get(m).push(r.bid);
  });
  const railMonthly = new Map();
  byMonth.forEach((vals, m) => railMonthly.set(m, vals.reduce((a,b)=>a+b,0)/vals.length));

  // merge with PNW volume on shared months
  const merged = PNW_MONTHLY.filter(p => railMonthly.has(p.month))
    .map(p => ({ month: p.month, mt: p.mt, bid: railMonthly.get(p.month) }));

  const head = document.createElement('div');
  head.className = 'card';
  const h = document.createElement('div'); h.className = 'card-head';
  h.innerHTML = '<div><p class="card-title">Secondary rail bid vs. PNW bulk export volume</p>' +
    '<p class="card-caption">Monthly BULK export tonnage (container cargo excluded) across 8 core Pacific Northwest grain terminals — Seattle, Tacoma, Portland OR, Vancouver WA, Longview, Kalama, Aberdeen WA &amp; Astoria — vs. each combination\'s monthly-average near-month bid. Source: USDA AgTransport port trade dataset v58g-swkr.</p></div>';
  const selRow = document.createElement('div'); selRow.className = 'select-row';
  selRow.innerHTML = 'Series <select id="pnw-select"></select>';
  h.appendChild(selRow);
  head.appendChild(h);
  panel.appendChild(head);

  const sel = selRow.querySelector('#pnw-select');
  combos.forEach(c => {
    const opt = document.createElement('option'); opt.value = c.key; opt.textContent = c.label;
    if (c.key === state.pnwFocus) opt.selected = true;
    sel.appendChild(opt);
  });
  sel.addEventListener('change', () => { state.pnwFocus = sel.value; renderPnw(); });

  // correlation stat tile
  const r = merged.length >= 3 ? pearsonR(merged.map(m=>m.mt), merged.map(m=>m.bid)) : null;
  const corrCard = document.createElement('div'); corrCard.className = 'card';
  corrCard.innerHTML = '<div class="kpi-row">' +
    '<div class="stat-tile"><div class="st-label">Correlation (Pearson r)</div><div class="st-value">' + (r === null ? 'n/a' : r.toFixed(2)) + '</div><div class="st-date">' + (r === null ? 'not enough overlapping months' : corrStrengthLabel(r)) + '</div></div>' +
    '<div class="stat-tile"><div class="st-label">Overlapping months</div><div class="st-value">' + merged.length + '</div><div class="st-date">' + (merged.length ? merged[0].month + ' to ' + merged[merged.length-1].month : '') + '</div></div>' +
    '</div>';
  panel.appendChild(corrCard);

  // stacked time series: PNW volume, then rail bid — same x domain, not overlaid (no dual axis)
  const tsCard = document.createElement('div'); tsCard.className = 'card';
  tsCard.innerHTML = '<div class="card-head"><div><p class="card-title">Both series over time</p><p class="card-caption">Two separate axes by design — tonnage and dollars aren\'t comparable on one scale.</p></div></div>';
  const pnwChartDiv = document.createElement('div'); pnwChartDiv.className = 'chart-wrap';
  const pnwLabel = document.createElement('p'); pnwLabel.className = 'card-caption'; pnwLabel.style.margin = '2px 0 6px 0'; pnwLabel.textContent = 'PNW bulk export volume (metric tons/month)';
  tsCard.appendChild(pnwLabel);
  tsCard.appendChild(pnwChartDiv);
  const railLabel = document.createElement('p'); railLabel.className = 'card-caption'; railLabel.style.margin = '14px 0 6px 0'; railLabel.textContent = combo.label + ' — monthly-average near-month bid ($)';
  tsCard.appendChild(railLabel);
  const railChartDiv = document.createElement('div'); railChartDiv.className = 'chart-wrap';
  tsCard.appendChild(railChartDiv);
  panel.appendChild(tsCard);

  const monthToMs = m => Date.UTC(Number(m.slice(0,4)), Number(m.slice(5,7)) - 1, 1);
  const xTicksFn = (min, max) => {
    const startY = new Date(min).getUTCFullYear(); const endY = new Date(max).getUTCFullYear();
    const step = Math.max(1, Math.round((endY - startY) / 8));
    const ticks = [];
    for (let y = Math.ceil(startY/step)*step; y <= endY; y += step) ticks.push({ x: Date.UTC(y,0,1), label: String(y) });
    return ticks;
  };

  drawLineChart(pnwChartDiv, [{ key:'pnw', label:'PNW export volume', color: pnwHue, points: merged.map(m => ({ x: monthToMs(m.month), y: m.mt, raw: m.mt })), directLabel:false, width:2 }], {
    height: 190, yFormat: fmtMt, xTicks: xTicksFn,
    tooltipTitle: x => new Date(x).toLocaleDateString('en-US',{year:'numeric',month:'short',timeZone:'UTC'}),
  });
  drawLineChart(railChartDiv, [{ key:'rail', label: combo.label, color: accent, points: merged.map(m => ({ x: monthToMs(m.month), y: m.bid, raw: m.bid })), directLabel:false, width:2 }], {
    height: 190, yFormat: fmtMoney, xTicks: xTicksFn,
    tooltipTitle: x => new Date(x).toLocaleDateString('en-US',{year:'numeric',month:'short',timeZone:'UTC'}),
  });

  // scatter
  const scCard = document.createElement('div'); scCard.className = 'card';
  scCard.innerHTML = '<div class="card-head"><div><p class="card-title">Scatter: export volume vs. bid</p><p class="card-caption">Each point is one month. Line is the least-squares fit.</p></div></div>';
  const scDiv = document.createElement('div'); scDiv.className = 'chart-wrap';
  scCard.appendChild(scDiv);
  panel.appendChild(scCard);
  drawScatterChart(scDiv, merged.map(m => ({ x: m.mt, y: m.bid, label: m.month })), {
    height: 320, color: accent, xFormat: fmtMt, yFormat: fmtMoney,
    xLabel: 'PNW bulk export volume', yLabel: combo.label + ' bid',
  });
}

/* ============================== GENERIC SCATTER CHART ============================== */
function drawScatterChart(container, points, opts) {
  container.innerHTML = '';
  const W = 900, H = opts.height || 320;
  const margin = { top: 14, right: 18, bottom: 30, left: 64 };
  const innerW = W - margin.left - margin.right, innerH = H - margin.top - margin.bottom;
  if (points.length < 2) { container.innerHTML = '<div class="empty-state">Not enough overlapping data to plot.</div>'; return; }

  const xMin = Math.min(...points.map(p=>p.x)), xMax = Math.max(...points.map(p=>p.x));
  const yMin = Math.min(...points.map(p=>p.y), 0), yMax = Math.max(...points.map(p=>p.y), 0);
  const xPad = (xMax-xMin)*0.06 || 1, yPad = (yMax-yMin)*0.08 || 1;
  const xt = niceTicks(xMin-xPad, xMax+xPad, 5);
  const yt = niceTicks(yMin-yPad, yMax+yPad, 5);
  const xScale = x => margin.left + (x - xt.min)/(xt.max-xt.min)*innerW;
  const yScale = y => margin.top + (1 - (y - yt.min)/(yt.max-yt.min))*innerH;

  const svg = svgEl('svg', { class:'chart-svg', viewBox:'0 0 '+W+' '+H, preserveAspectRatio:'none' });
  yt.ticks.forEach(tv => {
    const y = yScale(tv);
    svg.appendChild(svgEl('line', { class: tv===0?'baseline':'gridline', x1:margin.left, x2:W-margin.right, y1:y, y2:y }));
    const lbl = svgEl('text', { class:'axis-label', x:margin.left-8, y:y+3, 'text-anchor':'end' });
    lbl.textContent = opts.yFormat ? opts.yFormat(tv) : tv;
    svg.appendChild(lbl);
  });
  xt.ticks.forEach(tv => {
    const x = xScale(tv);
    const lbl = svgEl('text', { class:'axis-label', x:x, y:H-8, 'text-anchor':'middle' });
    lbl.textContent = opts.xFormat ? opts.xFormat(tv) : tv;
    svg.appendChild(lbl);
  });

  // trend line
  const { slope, intercept } = linRegress(points.map(p=>p.x), points.map(p=>p.y));
  const tx1 = xt.min, tx2 = xt.max;
  svg.appendChild(svgEl('line', {
    x1:xScale(tx1), y1:yScale(slope*tx1+intercept), x2:xScale(tx2), y2:yScale(slope*tx2+intercept),
    stroke: cssVar('--text-muted'), 'stroke-width':1.5, 'stroke-dasharray':'5,4'
  }));

  const tooltip = document.getElementById('tooltip');
  points.forEach(p => {
    const cx = xScale(p.x), cy = yScale(p.y);
    const dot = svgEl('circle', { cx, cy, r:4, fill: opts.color, opacity:0.75 });
    const hit = svgEl('circle', { cx, cy, r:12, fill:'transparent', style:'cursor:pointer' });
    hit.addEventListener('pointerenter', () => {
      dot.setAttribute('r', 6);
      tooltip.innerHTML = '';
      const t = document.createElement('div'); t.className='tt-date'; t.textContent = p.label; tooltip.appendChild(t);
      const row1 = document.createElement('div'); row1.className='tt-row';
      row1.innerHTML = '<div class="tt-name">'+(opts.xLabel||'x')+'</div><div class="tt-val"></div>';
      row1.querySelector('.tt-val').textContent = opts.xFormat ? opts.xFormat(p.x) : p.x;
      const row2 = document.createElement('div'); row2.className='tt-row';
      row2.innerHTML = '<div class="tt-name">'+(opts.yLabel||'y')+'</div><div class="tt-val"></div>';
      row2.querySelector('.tt-val').textContent = opts.yFormat ? opts.yFormat(p.y) : p.y;
      tooltip.appendChild(row1); tooltip.appendChild(row2);
      tooltip.style.opacity = '1';
      const contRect = container.getBoundingClientRect();
      const svgRect = svg.getBoundingClientRect();
      tooltip.style.left = (cx/W*svgRect.width + (svgRect.left-contRect.left) + 14) + 'px';
      tooltip.style.top = (cy/H*svgRect.height + (svgRect.top-contRect.top) - 10) + 'px';
    });
    hit.addEventListener('pointerleave', () => { dot.setAttribute('r',4); tooltip.style.opacity='0'; });
    svg.appendChild(dot); svg.appendChild(hit);
  });

  container.appendChild(svg);
}

/* ---------- Snapshot tab ---------- */
function renderSnapshot() {
  const panel = document.getElementById('panel-snapshot');
  panel.innerHTML = '';
  const combos = visibleCombos();

  const kpiCard = document.createElement('div');
  kpiCard.className = 'card';
  kpiCard.innerHTML = '<div class="card-head"><div><p class="card-title">Latest near-month bid by railroad &amp; service</p>' +
    '<p class="card-caption">Most recent reported bid for the nearest-month contract, vs. the prior report for the same combination.</p></div></div>';
  const kpiRow = document.createElement('div');
  kpiRow.className = 'kpi-row';
  kpiCard.appendChild(kpiRow);

  combos.forEach(combo => {
    const rows = comboRows(combo, true);
    if (rows.length === 0) return;
    const last = rows[rows.length - 1];
    const prev = rows.length > 1 ? rows[rows.length - 2] : null;
    const delta = prev ? last.bid - prev.bid : 0;
    const tile = document.createElement('div');
    tile.className = 'stat-tile';
    const deltaClass = delta > 0 ? 'up' : (delta < 0 ? 'down' : 'flat');
    tile.innerHTML =
      '<div class="st-label"><span class="dot" style="background:var(' + combo.color + ')"></span>' + combo.label + '</div>' +
      '<div class="st-value">' + fmtMoney(last.bid) + '</div>' +
      '<div class="st-delta ' + deltaClass + '">' + (prev ? (fmtDelta(delta) + ' vs prior report') : 'no prior report') + '</div>' +
      '<div class="st-spark" id="spark-' + combo.key.replace('|','-') + '"></div>' +
      '<div class="st-date">as of ' + last.date + '</div>';
    kpiRow.appendChild(tile);
    setTimeout(() => {
      const el = tile.querySelector('.st-spark');
      const pts = rows.slice(-12).map((r, i) => ({ x: i, y: r.bid }));
      drawSparkline(el, pts, cssVar(combo.color));
    }, 0);
  });
  panel.appendChild(kpiCard);

  // forward curve
  const curveCard = document.createElement('div');
  curveCard.className = 'card';
  curveCard.innerHTML = '<div class="card-head"><div><p class="card-title">Current forward curve</p>' +
    '<p class="card-caption">Bid by contract month horizon, from each combination\'s most recent report date &mdash; the secondary market\'s current term structure.</p></div></div>';
  const curveChart = document.createElement('div');
  curveChart.className = 'chart-wrap';
  curveCard.appendChild(curveChart);
  const legendDiv = document.createElement('div'); legendDiv.className = 'legend';
  curveCard.appendChild(legendDiv);
  panel.appendChild(curveCard);

  const series = combos.map(combo => {
    const rows = ROWS.filter(r => r.company === combo.company && r.type === combo.type);
    if (rows.length === 0) return null;
    const latestDate = rows.reduce((a, r) => r.date > a ? r.date : a, rows[0].date);
    const pts = rows.filter(r => r.date === latestDate).sort((a, b) => a.horizon - b.horizon)
      .map(r => ({ x: r.horizon, y: r.bid, raw: r.bid }));
    return { key: combo.key, label: combo.label + ' (' + latestDate + ')', color: cssVar(combo.color), points: pts, directLabel: false };
  }).filter(Boolean);

  drawLineChart(curveChart, series, {
    height: 260,
    yFormat: fmtMoney,
    xTicks: (min, max) => {
      const t = [];
      for (let h = Math.ceil(min); h <= Math.floor(max); h++) t.push({ x: h, label: h + ' mo' });
      return t;
    },
    tooltipTitle: (x) => x + ' month' + (x === 1 ? '' : 's') + ' out',
  });
  series.forEach(s => {
    const item = document.createElement('div'); item.className = 'legend-item';
    item.innerHTML = '<span class="key" style="background:' + s.color + '"></span>' + s.label;
    legendDiv.appendChild(item);
  });

  if (combos.length === 0) {
    panel.innerHTML = '<div class="empty-state">Select at least one railroad and service type above.</div>';
  }
}

/* ---------- Full history tab ---------- */
function renderHistory() {
  const panel = document.getElementById('panel-history');
  panel.innerHTML = '';
  const combos = visibleCombos();
  if (combos.length === 0) { panel.innerHTML = '<div class="empty-state">Select at least one railroad and service type above.</div>'; return; }

  const card = document.createElement('div');
  card.className = 'card';
  card.innerHTML = '<div class="card-head"><div><p class="card-title">Near-month bid, full history (1997&ndash;2026)</p>' +
    '<p class="card-caption">Weekly reported bid for the nearest-month secondary market contract.</p></div>' +
    '<button class="table-toggle-btn" id="history-table-btn">Table view</button></div>';
  const chartDiv = document.createElement('div'); chartDiv.className = 'chart-wrap';
  card.appendChild(chartDiv);
  const legendDiv = document.createElement('div'); legendDiv.className = 'legend';
  card.appendChild(legendDiv);
  const tableDiv = document.createElement('div'); tableDiv.style.display = 'none'; tableDiv.style.marginTop = '12px';
  card.appendChild(tableDiv);
  panel.appendChild(card);

  const comboSeries = combos.map(combo => {
    const rows = comboRows(combo, true);
    return { key: combo.key, label: combo.label, color: cssVar(combo.color), points: rows.map(r => ({ x: r.t, y: r.bid, raw: r.bid })), _rows: rows, directLabel: false };
  });

  function draw() {
    const active = comboSeries.filter(s => !state.isolatedOff || !state.isolatedOff.has(s.key));
    drawLineChart(chartDiv, active, {
      height: 320,
      yFormat: fmtMoney,
      xTicks: (min, max) => {
        const startY = new Date(min).getUTCFullYear();
        const endY = new Date(max).getUTCFullYear();
        const step = Math.max(1, Math.round((endY - startY) / 8));
        const ticks = [];
        for (let y = Math.ceil(startY / step) * step; y <= endY; y += step) {
          ticks.push({ x: Date.UTC(y, 0, 1), label: String(y) });
        }
        return ticks;
      },
      tooltipTitle: (x) => new Date(x).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric', timeZone: 'UTC' }),
    });
  }
  state.isolatedOff = state.isolatedOff || new Set();
  draw();

  legendDiv.innerHTML = '';
  comboSeries.forEach(s => {
    const item = document.createElement('div');
    item.className = 'legend-item' + (state.isolatedOff.has(s.key) ? ' isolated-off' : '');
    item.innerHTML = '<span class="key" style="background:' + s.color + '"></span>' + s.label;
    item.addEventListener('click', () => {
      if (state.isolatedOff.has(s.key)) state.isolatedOff.delete(s.key); else state.isolatedOff.add(s.key);
      renderHistory();
    });
    legendDiv.appendChild(item);
  });

  const tableBtn = document.getElementById('history-table-btn');
  let tableShown = false;
  tableBtn.addEventListener('click', () => {
    tableShown = !tableShown;
    tableBtn.classList.toggle('active', tableShown);
    tableDiv.style.display = tableShown ? '' : 'none';
    if (tableShown && tableDiv.innerHTML === '') {
      // wide pivot: date x combo
      const dateMap = new Map();
      comboSeries.forEach(s => s._rows.forEach(r => {
        if (!dateMap.has(r.date)) dateMap.set(r.date, {});
        dateMap.get(r.date)[s.key] = r.bid;
      }));
      const dates = [...dateMap.keys()].sort().reverse();
      let html = '<div class="table-scroll"><table class="data-table"><thead><tr><th>Date</th>';
      comboSeries.forEach(s => html += '<th>' + s.label + '</th>');
      html += '</tr></thead><tbody>';
      dates.forEach(d => {
        html += '<tr><td>' + d + '</td>';
        comboSeries.forEach(s => {
          const v = dateMap.get(d)[s.key];
          html += '<td>' + (v === undefined ? '&mdash;' : fmtMoney(v)) + '</td>';
        });
        html += '</tr>';
      });
      html += '</tbody></table></div>';
      tableDiv.innerHTML = html;
    }
  });
}

/* ---------- Seasonal comparison tab ---------- */
function renderSeasonal() {
  const panel = document.getElementById('panel-seasonal');
  panel.innerHTML = '';
  const combos = visibleCombos();
  if (combos.length === 0) { panel.innerHTML = '<div class="empty-state">Select at least one railroad and service type above.</div>'; return; }

  if (!state.seasonalFocus || !combos.find(c => c.key === state.seasonalFocus)) state.seasonalFocus = combos[0].key;

  const card = document.createElement('div');
  card.className = 'card';
  const head = document.createElement('div'); head.className = 'card-head';
  head.innerHTML = '<div><p class="card-title">Current year vs. prior years, by week</p>' +
    '<p class="card-caption">Each gray line is one historical year; the current year is highlighted (solid = actual near-month bid). The dashed continuation is the most recently quoted forward bid for months the market has already priced but haven\'t arrived yet — real market pricing, not a statistical forecast.</p></div>';
  const selRow = document.createElement('div'); selRow.className = 'select-row';
  selRow.innerHTML = 'Series <select id="seasonal-select"></select>';
  head.appendChild(selRow);
  card.appendChild(head);
  const chartDiv = document.createElement('div'); chartDiv.className = 'chart-wrap';
  card.appendChild(chartDiv);
  panel.appendChild(card);

  const sel = selRow.querySelector('#seasonal-select');
  combos.forEach(c => {
    const opt = document.createElement('option'); opt.value = c.key; opt.textContent = c.label;
    if (c.key === state.seasonalFocus) opt.selected = true;
    sel.appendChild(opt);
  });
  sel.addEventListener('change', () => { state.seasonalFocus = sel.value; renderSeasonal(); });

  const combo = combos.find(c => c.key === state.seasonalFocus);
  const rows = comboRows(combo, true);
  const byYear = new Map();
  rows.forEach(r => {
    const y = Number(r.date.slice(0, 4));
    const wk = dayOfYearWeek(r.date);
    if (!byYear.has(y)) byYear.set(y, []);
    byYear.get(y).push({ x: wk, y: r.bid, raw: r.bid, date: r.date });
  });
  const years = [...byYear.keys()].sort();
  const currentYear = years[years.length - 1];
  const accent = cssVar(combo.color);

  // forward-curve extension for the current year: most recent quote per remaining month,
  // placed at the week-of-year of that month's 15th (a representative mid-month position)
  const { projected, lastActualMonth } = getYearProjection(combo, currentYear);
  const weekOfMonth15 = m => dayOfYearWeek(currentYear + '-' + String(m).padStart(2,'0') + '-15');
  const currentYearPts = byYear.get(currentYear).sort((a,b) => a.x - b.x);
  const lastActualPt = currentYearPts.length ? currentYearPts[currentYearPts.length-1] : null;
  const projRuns = projected.length
    ? projectedRuns(projected, lastActualMonth, lastActualPt ? { x: lastActualPt.x, y: lastActualPt.y, raw: lastActualPt.y } : null, weekOfMonth15)
    : [];

  const series = years.map(y => {
    const pts = byYear.get(y).sort((a, b) => a.x - b.x);
    const isCurrent = y === currentYear;
    return { key: 'y' + y, label: String(y), color: isCurrent ? accent : '', muted: !isCurrent, points: pts, directLabel: isCurrent && projRuns.length === 0, width: isCurrent ? 2.5 : 1.5 };
  });
  projRuns.forEach((pts, i) => {
    series.push({ key: 'proj-' + i, label: String(currentYear), color: accent, points: pts, directLabel: i === projRuns.length - 1, width: 2.5, dashed: true });
  });

  drawLineChart(chartDiv, series, {
    height: 320,
    yFormat: fmtMoney,
    xTicks: (min, max) => {
      const monthStarts = [1,5,9,14,18,23,27,31,36,40,44,48];
      const names = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      return monthStarts.map((w, i) => ({ x: w, label: names[i] }));
    },
    tooltipTitle: (x) => 'Week ' + x,
  });

  const cap = document.createElement('p'); cap.className = 'card-caption'; cap.style.marginTop = '10px';
  let capText = combo.label + ' data available from ' + years[0] + ' onward (' + years.length + ' years shown).';
  if (projected.length) {
    const latestAsOf = [...new Set(projected.map(p=>p.asOf))].sort().slice(-1)[0];
    capText += ' Forward-quoted months as of report dates through ' + latestAsOf + '; months beyond the market\'s current quoting horizon are left blank.';
  }
  cap.textContent = capText;
  card.appendChild(cap);
}

/* ---------- Trailing average tab ---------- */
function renderTrailing() {
  const panel = document.getElementById('panel-trailing');
  panel.innerHTML = '';
  const combos = visibleCombos();
  if (combos.length === 0) { panel.innerHTML = '<div class="empty-state">Select at least one railroad and service type above.</div>'; return; }

  if (!state.trailingFocus || !combos.find(c => c.key === state.trailingFocus)) state.trailingFocus = combos[0].key;

  const combo = combos.find(c => c.key === state.trailingFocus);
  const rows = comboRows(combo, true);
  const WINDOW = 52;
  const rolling = rows.map((r, i) => {
    const start = Math.max(0, i - WINDOW + 1);
    const slice = rows.slice(start, i + 1);
    const avg = slice.reduce((a, x) => a + x.bid, 0) / slice.length;
    return avg;
  });
  const allTimeAvg = rows.reduce((a, r) => a + r.bid, 0) / rows.length;
  const last = rows[rows.length - 1];
  const lastRolling = rolling[rolling.length - 1];
  const deltaVsRolling = last.bid - lastRolling;

  const kpiCard = document.createElement('div');
  kpiCard.className = 'card';
  const head = document.createElement('div'); head.className = 'card-head';
  head.innerHTML = '<div><p class="card-title">Current value vs. trailing average</p>' +
    '<p class="card-caption">Near-month bid compared against its own rolling and all-time average.</p></div>';
  const selRow = document.createElement('div'); selRow.className = 'select-row';
  selRow.innerHTML = 'Series <select id="trailing-select"></select>';
  head.appendChild(selRow);
  kpiCard.appendChild(head);

  const kpiRow = document.createElement('div'); kpiRow.className = 'kpi-row';
  const deltaClass = deltaVsRolling > 0 ? 'up' : (deltaVsRolling < 0 ? 'down' : 'flat');
  const deltaVsAllTime = lastRolling - allTimeAvg;
  const deltaAllTimeClass = deltaVsAllTime > 0 ? 'up' : (deltaVsAllTime < 0 ? 'down' : 'flat');
  kpiRow.innerHTML =
    '<div class="stat-tile"><div class="st-label">Latest bid</div><div class="st-value">' + fmtMoney(last.bid) + '</div><div class="st-delta ' + deltaClass + '">' + fmtDelta(deltaVsRolling) + ' vs 52-wk average</div><div class="st-date">as of ' + last.date + '</div></div>' +
    '<div class="stat-tile"><div class="st-label">52-week trailing average</div><div class="st-value">' + fmtMoney(lastRolling) + '</div><div class="st-delta ' + deltaAllTimeClass + '">' + fmtDelta(deltaVsAllTime) + ' vs all-time average</div></div>' +
    '<div class="stat-tile"><div class="st-label">All-time average</div><div class="st-value">' + fmtMoney(allTimeAvg) + '</div><div class="st-date">since ' + rows[0].date + '</div></div>';
  kpiCard.appendChild(kpiRow);
  panel.appendChild(kpiCard);

  const chartCard = document.createElement('div'); chartCard.className = 'card';
  chartCard.innerHTML = '<div class="card-head"><div><p class="card-title">Weekly bid with 52-week rolling average</p></div></div>';
  const chartDiv = document.createElement('div'); chartDiv.className = 'chart-wrap';
  chartCard.appendChild(chartDiv);
  const legendDiv = document.createElement('div'); legendDiv.className = 'legend';
  chartCard.appendChild(legendDiv);
  panel.appendChild(chartCard);

  const sel = selRow.querySelector('#trailing-select');
  combos.forEach(c => {
    const opt = document.createElement('option'); opt.value = c.key; opt.textContent = c.label;
    if (c.key === state.trailingFocus) opt.selected = true;
    sel.appendChild(opt);
  });
  sel.addEventListener('change', () => { state.trailingFocus = sel.value; renderTrailing(); });

  const accent = cssVar(combo.color);
  const series = [
    { key: 'raw', label: 'Weekly bid', color: '', muted: true, points: rows.map(r => ({ x: r.t, y: r.bid, raw: r.bid })), directLabel: false },
    { key: 'roll', label: '52-week average', color: accent, points: rows.map((r, i) => ({ x: r.t, y: rolling[i], raw: rolling[i] })), width: 2.5, directLabel: false },
  ];
  drawLineChart(chartDiv, series, {
    height: 300,
    yFormat: fmtMoney,
    xTicks: (min, max) => {
      const startY = new Date(min).getUTCFullYear();
      const endY = new Date(max).getUTCFullYear();
      const step = Math.max(1, Math.round((endY - startY) / 8));
      const ticks = [];
      for (let y = Math.ceil(startY / step) * step; y <= endY; y += step) ticks.push({ x: Date.UTC(y, 0, 1), label: String(y) });
      return ticks;
    },
    tooltipTitle: (x) => new Date(x).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric', timeZone: 'UTC' }),
  });
  legendDiv.innerHTML =
    '<div class="legend-item"><span class="key" style="background:' + cssVar('--text-muted') + '"></span>Weekly bid</div>' +
    '<div class="legend-item"><span class="key" style="background:' + accent + '"></span>52-week average</div>';
}

/* ============================== THEME TOGGLE ============================== */
const themeBtn = document.getElementById('theme-toggle');
let isDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
function applyTheme() {
  document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
  themeBtn.textContent = isDark ? 'Light mode' : 'Dark mode';
}
themeBtn.addEventListener('click', () => { isDark = !isDark; applyTheme(); renderActiveTab(); });
applyTheme();

/* ============================== INIT ============================== */
loadData().then(() => {
  renderFilterUI();
  renderActiveTab();
  console.log('LOADED_OK', ROWS.length, COMBOS.length);
}).catch(err => {
  console.error('Failed to load dashboard data:', err);
  document.getElementById('meta-line').textContent = 'Failed to load data — see console. If you opened this file directly (file://), serve it over HTTP instead (e.g. `python3 -m http.server`).';
});
